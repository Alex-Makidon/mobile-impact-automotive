document.getElementById('year').textContent = new Date().getFullYear();
// Replace with your shop's Google reviews link if you have it
document.getElementById('google-link').href = '#';
